/*const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: String,
  idNumber: String,
  phoneNumber: String,
  email: String,
  password: String
});

const User = mongoose.model('User', userSchema);

module.exports = User;*/